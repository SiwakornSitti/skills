
export async function extractAndScopeStyles(content: string): Promise<string> {
  let rawCss = "";
  let hasStyle = false;

  const rewriter = new HTMLRewriter().on("head > style", {
    element() {
      hasStyle = true;
    },
    text(chunk) {
      rawCss += chunk.text;
    }
  });

  // Process the HTML to extract the CSS
  await rewriter.transform(new Response(content)).text();

  if (!hasStyle) return content;

  const formattedCSS = rawCss.replace(/(^|})([^{]+)/g, (match, sep, selector) => {
    if (selector.trim().startsWith("/*") || !selector.trim()) return match;
    // Removed the .root prefix to keep the original selectors
    return `${sep} ${selector.trim()}`;
  });

  // Clean the CSS
  const finalCss = formattedCSS.replace(/body\s*\{([^}]*)\}/g, "").trim();

  // Second pass to inject the new CSS and return the full HTML
  const finalHtml = await new HTMLRewriter().on("head > style", {
    element(el) {
      el.setInnerContent(finalCss);
    }
  }).transform(new Response(content)).text();

  return finalHtml;
}

// Example usage:
async function run() {
  const file = Bun.file("response.json");
  const data = await file.json();
  
  // Replace any literal escaped quotes `\"` that might have been double-escaped in the JSON
  const html = typeof data.content === "string" 
    ? data.content.replaceAll('\\"', '"') 
    : data.content;

  if (!html) {
    console.error("No 'content' property found in response.json");
    return;
  }

  const scopedHtml = await extractAndScopeStyles(html);

  const outputPath = "output.html";
  await Bun.write(outputPath, scopedHtml);
  console.log(`Scoped HTML successfully written to ${outputPath}`);
}

if (import.meta.main) {
  run();
}
